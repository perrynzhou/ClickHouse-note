#pragma once

namespace DB
{

void registerFunctions();

}
