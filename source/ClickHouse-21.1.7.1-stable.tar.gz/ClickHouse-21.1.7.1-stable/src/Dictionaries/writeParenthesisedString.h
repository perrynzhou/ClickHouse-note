#pragma once

#include <IO/WriteHelpers.h>


namespace DB
{
void writeParenthesisedString(const String & s, WriteBuffer & buf);


}
